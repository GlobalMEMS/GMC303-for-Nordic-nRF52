/* Copyright (c) 2014 Nordic Semiconductor. All Rights Reserved.
 *
 * The information contained herein is property of Nordic Semiconductor ASA.
 * Terms and conditions of usage are described in detail in NORDIC
 * SEMICONDUCTOR STANDARD SOFTWARE LICENSE AGREEMENT.
 *
 * Licensees are granted free, non-transferable use of the information. NO
 * WARRANTY of ANY KIND is provided. This heading must NOT be removed from
 * the file.
 *
 */

/** @file
 * @defgroup nrf_dev_timer_example_main main.c
 * @{
 * @ingroup nrf_dev_timer_example
 * @brief Timer Example Application main file.
 *
 * This file contains the source code for a sample application using Timer0.
 *
 */

#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "app_uart.h"
#include "nrf.h"
#include "bsp.h"
#include "nrf_drv_twi.h"
#include "nrf_drv_timer.h"
#include "bsp.h"
#include "app_error.h"
#include "app_uart.h"
#include "I2C.h"
#include "gmc303.h"
#include "gma303.h"
#include "gmp102.h"
#include "gSensor_autoNil.h"
#include "nrf_delay.h"
#include "AKFS_APIs.h"  
#include "string.h"
#include "misc_util.h"
#include "pSensor_util.h"
raw_data_xyzt_t gRawData, mRawData;
float_xyzt_t mCalibData;
float_xyzt_t gOffsetData;
float_xyzt_t mAdjustVal = { 1.0, 1.0, 1.0, 0.0 };

int16_t i16AkmdfsRes, i16Accuracy, i16Accuracy_pre, i16Orientation;
int16_t i16RawData[3];
float_xyzt_t fv_avec;
float_xyzt_t fv_hvec;
AKMPRMS akmdfsPRMS;
AKFVEC fv_ho_pre = {0.0f, 0.0f, 0.0f};
AKFLOAT f_azimuth;
AKFLOAT f_pitch;
AKFLOAT f_roll;
uint8_t u8Asaxyz[3]; //ASAX/Y/Z
//const int32_t akfs_over_sampling_ratio = (int32_t)(SAMPLING_RATE_HZ / AKFS_DATA_RATE_HZ + 0.5);
int32_t akfsIcounter = 0;



#define MAX_TEST_DATA_BYTES     (15U)                /**< max number of test bytes to be used for tx and rx. */
#define UART_TX_BUF_SIZE 256                         /**< UART TX buffer size. */
#define UART_RX_BUF_SIZE 1                           /**< UART RX buffer size. */
#define DELAY_MS(ms)	nrf_delay_us(ms*1000)

const nrf_drv_timer_t TIMER_LED = NRF_DRV_TIMER_INSTANCE(0);
const uint8_t leds_list[LEDS_NUMBER] = LEDS_LIST;

void timer_led_event_handler(nrf_timer_event_t event_type, void* p_context);
void timer_LED_init(void);
void uart_init(void);
void uart_error_handle(app_uart_evt_t * p_event);
static const nrf_drv_twi_t m_twi_master = NRF_DRV_TWI_INSTANCE(1);
static ret_code_t twi_master_init(void);

volatile bool timer_flag=0;

float SOFT_IRON_MATRIX[3][3]={{1.0f,0.0f,0.0f},{0.0f,1.0f,0.0f},{0.0f,0.0f,1.0f}};



/**
 * @brief Function for main application entry.
 */
int main(void)
{  
	/////////////////////////andy for gsensor
  	int i;
		uint8_t u8Data[9];
		s16 v[3]={0,0,0},avg[3],s16Tmp;
///////////////////////// for gmp102
	s8 s8Res; 
 float fCalibParam[GMP102_CALIBRATION_PARAMETER_COUNT], fT_Celsius, fP_Pa, fAlt_m;
	s16 s16T;
	s32 s32P;	
		
/////////////////////////	
		int8_t res;
		timer_LED_init();
    uart_init();
    twi_master_init();
						
		res=gmc303_bus_init();
		//printf("CMPID=0x%02x\n\r",res);
	///////////////////////////gmp102
		gmp102_bus_init();
		/* GMP102 soft reset */
	s8Res = gmp102_soft_reset();
		
	  // printf("%d,%s,init_result=%d\n\r",__LINE__,__FUNCTION__,s8Res);

	/* Wait 100ms for reset complete */
	   DELAY_MS(1000);
	
	/* GMP102 get the pressure calibration parameters */
	s8Res = gmp102_get_calibration_param(fCalibParam);
	  // printf("%d,%s,init_result=%d\n\r",__LINE__,__FUNCTION__,s8Res);

	/* GMP102 initialization setup */
	s8Res = gmp102_initialization();
  // printf("%d,%s,init_result=%d\n\r",__LINE__,__FUNCTION__,s8Res);
	/* set sea level reference pressure */
	//If not set, use default 101325 Pa for pressure altitude calculation
	set_sea_level_pressure_base(100681.f); 

	#if 1
		 while(1)
		 {
		/* Measure P */
		//printf("%d,%s\n\r",__LINE__,__FUNCTION__);
		s8Res = gmp102_measure_P(&s32P);
		//printf("P(code)=%d\r", s32P);
		printf("pCODEis-%d=\n\r",s32P);

             //  printf("%d,%s\n\r",__LINE__,__FUNCTION__);
		/* Mesaure T */
		s8Res = gmp102_measure_T(&s16T);
			printf("TCODEis=%d\n\r",s16T);

		//printf("T(code)=%d\r", s16T);
		//printf("%d,%s\n\r",__LINE__,__FUNCTION__);

		/* Compensation */
		gmp102_compensation(s16T, s32P, fCalibParam, &fT_Celsius, &fP_Pa);
		printf("Compensationis=%f,%f\n\r",fP_Pa,fT_Celsius);

		//printf("P(Pa)=%f\r", fP_Pa);
		//printf("T(C)=%f\r", fT_Celsius);

		/* Pressure Altitude */
		//fAlt_m = pressure2Alt(102100.f);
		fAlt_m = pressure2Alt(fP_Pa);
		printf("Pressure Altitudeis=%f\n\r",fAlt_m);

		//printf("Alt(m)=%f\r", fAlt_m);

		/* Delay 1 sec */
		DELAY_MS(1000);			 
			 
		 }
		#endif
		
	///////////////////// gsensor
	  gma303_soft_reset();
         gma303_initialization();
		gOffsetData.u.x=gOffsetData.u.y=gOffsetData.u.z=0;
		for(i=0;i<10;i++)
		{
			gma303_burst_read(GMA303_STADR__REG, u8Data, 9);
		for(int j=0;j<10;j++)
				nrf_delay_us(999);
		}
		gSensorAutoNil_f(gma303_read_data_xyz, AUTONIL_AUTO + AUTONIL_Z, GMA303_RAW_DATA_SENSITIVITY, &gOffsetData);
	//	coord_rotate_f(PAT2, &gOffsetData);
		
		
		//		coord_rotate_f(PAT6, &gOffsetData);

		/*for(i=0;i<10;i++)
		{
			gma303_burst_read(GMA303_STADR__REG, u8Data, 9);
			//printf("raw=,0x%02x,0x%02x,0x%02x,0x%02x,0x%02x,0x%02x,0x%02x,0x%02x,0x%02x\n\r",
			//u8Data[0],u8Data[1],u8Data[2],u8Data[3],u8Data[4],u8Data[5],u8Data[6],u8Data[7],u8Data[8]);
			for(int j = 0; j < 3;j++){
				s16Tmp = (u8Data[2*j + 4] << 8) | (u8Data[2*j + 3]);
				v[j]+=s16Tmp;
				printf("%d ",s16Tmp);
			}				
			printf("\n\r");
			for(int j=0;j<10;j++)
				nrf_delay_us(999);
		}
		gOffsetData.u.x=(float)v[0]/10.0f;
		gOffsetData.u.y=(float)v[1]/10.0f;
		gOffsetData.u.z=(float)v[2]/10.0f;*/
		printf("gsensoroffset ��%6.1f,%6.1f,%6.1f\n\r",gOffsetData.u.x,gOffsetData.u.y,gOffsetData.u.z);

	///////////////////
		  gmc303_soft_reset();  //soft reset
      gmc303_get_sensitivity_adjust_val(&mAdjustVal);  //adjustvalue
	    gmc303_burst_read(GMC303_ASA_XYZ_START__REG, u8Asaxyz, 3); //asaxyz
      gmc303_set_operation_mode(GMC303_OP_MODE_CM_100HZ);  

	
	  //Initialization: akmdfs algorithm

  i16AkmdfsRes = AKFS_Init(&akmdfsPRMS, PAT1, u8Asaxyz, gOffsetData.v, GMA303_RAW_DATA_SENSITIVITY);
//printf("----i16AkmdfsRes--%d-,%d-%d-%d--\n\r",i16AkmdfsRes,u8Asaxyz[0],u8Asaxyz[1],u8Asaxyz[2]);

  i16AkmdfsRes = AKFS_Start(&akmdfsPRMS);
	

//printf("----i16AkmdfsRes--%d-,%d-%d-%d--\n\r",i16AkmdfsRes,u8Asaxyz[0],u8Asaxyz[1],u8Asaxyz[2]);
	
    while(1)
    {
			while(timer_flag==0);
			//u8 u8Data[6];
			
		      gma303_read_data_xyzt(&gRawData);
      for(i = 0; i < 3; ++i){
				i16RawData[i] = gRawData.v[i];
      }
		//printf("raw ��%d,%d,%d ",i16RawData[0],i16RawData[1],i16RawData[2]);
		//printf("offset ��%6.1f,%6.1f,%6.1f ",gOffsetData.u.x,gOffsetData.u.y,gOffsetData.u.z);

				AKFS_Get_ACCELEROMETER(&akmdfsPRMS,
			       i16RawData,
			       0, //status of accelerometer, not used
			       &fv_avec.u.x, &fv_avec.u.y, &fv_avec.u.z,
			       &i16Accuracy);

		//printf("fv_avec=,%6.1f,%6.1f,%6.1f\n\r",fv_avec.u.x,fv_avec.u.y,fv_avec.u.z);

			gmc303_read_data_xyz(&mRawData);
      for(i = 0; i < 3; ++i){
	    i16RawData[i] = mRawData.v[i];
      }
	 i16AkmdfsRes = 
	AKFS_Get_MAGNETIC_FIELD(&akmdfsPRMS,
				i16RawData,
				0x01,  //success
				&fv_hvec.u.x, &fv_hvec.u.y, &fv_hvec.u.z,
				&i16Accuracy);		

		coord_rotate_f(PAT1, &fv_hvec);
		coord_rotate_f(PAT1, &fv_avec);
			
			
			
	AKFS_Get_ORIENTATION(&akmdfsPRMS,
			     &f_azimuth,
			     &f_pitch,
			     &f_roll,
			     &i16Orientation);
		printf("Accuracy=,%d,radius=,%5.1f,m(x,y,z)=,%5.1f,%5.1f,%5.1f,",i16Accuracy,sqrt(fv_hvec.u.x*fv_hvec.u.x+fv_hvec.u.y*fv_hvec.u.y+fv_hvec.u.z*fv_hvec.u.z),fv_hvec.u.x,fv_hvec.u.y,fv_hvec.u.z);
		printf("acc(x,y,z)=,%5.1f,%5.1f,%5.1f,",fv_avec.u.x,fv_avec.u.y,fv_avec.u.z);
		printf("rpy=,%6.1f,%6.1f,%6.1f \n\r",f_azimuth,f_pitch,f_roll);
			timer_flag=0;				
      __WFI();	
    }
}


/**
 * @brief Initialize the master TWI
 *
 * Function used to initialize master TWI interface that would communicate with simulated EEPROM.
 *
 * @return NRF_SUCCESS or the reason of failure
 */
static ret_code_t twi_master_init(void)
{
	ret_code_t ret;
	uint32_t err_code = NRF_SUCCESS;
	const nrf_drv_twi_config_t config =
	{
		 .scl                = TWI1_CONFIG_SCL,
		 .sda                = TWI1_CONFIG_SDA,
		 .frequency          = NRF_TWI_FREQ_400K,
		 .interrupt_priority = APP_IRQ_PRIORITY_HIGH
	};

	do
	{
			ret = nrf_drv_twi_init(&m_twi_master, &config, NULL);
			if(NRF_SUCCESS != ret)
			{
					break;
			}
			nrf_drv_twi_enable(&m_twi_master);
	}while(0);
	APP_ERROR_CHECK(err_code);

	return ret;
}

void uart_error_handle(app_uart_evt_t * p_event)
{
    if (p_event->evt_type == APP_UART_COMMUNICATION_ERROR)
    {
        APP_ERROR_HANDLER(p_event->data.error_communication);
    }
    else if (p_event->evt_type == APP_UART_FIFO_ERROR)
    {
        APP_ERROR_HANDLER(p_event->data.error_code);
    }
}

/**
 * @brief Handler for timer events.
 */
void timer_led_event_handler(nrf_timer_event_t event_type, void* p_context)
{
    static uint32_t i;
    uint32_t led_to_invert = (1 << leds_list[(i++) % LEDS_NUMBER]);
    switch(event_type)
    {
        case NRF_TIMER_EVENT_COMPARE0:
            LEDS_INVERT(led_to_invert);
            break;
        
        default:
            //Do nothing.
            break;
    }    
		timer_flag=1;
}

void timer_LED_init(void)
{
	  uint32_t time_ms = 125; //Time(in miliseconds) between consecutive compare events.
    uint32_t time_ticks;
    uint32_t err_code = NRF_SUCCESS;
    
    //Configure all leds on board.
    LEDS_CONFIGURE(LEDS_MASK);
    LEDS_OFF(LEDS_MASK);
    
    //Configure TIMER_LED for generating simple light effect - leds on board will invert his state one after the other.
    err_code = nrf_drv_timer_init(&TIMER_LED, NULL, timer_led_event_handler);
    APP_ERROR_CHECK(err_code);
    
    time_ticks = nrf_drv_timer_ms_to_ticks(&TIMER_LED, time_ms);
    
    nrf_drv_timer_extended_compare(
         &TIMER_LED, NRF_TIMER_CC_CHANNEL0, time_ticks, NRF_TIMER_SHORT_COMPARE0_CLEAR_MASK, true);
    
    nrf_drv_timer_enable(&TIMER_LED);
}	

void uart_init(void)
{
	uint32_t err_code = NRF_SUCCESS;

	const app_uart_comm_params_t comm_params =
	{
			RX_PIN_NUMBER,
			TX_PIN_NUMBER,
			RTS_PIN_NUMBER,
			CTS_PIN_NUMBER,
			APP_UART_FLOW_CONTROL_ENABLED,
			false,
			UART_BAUDRATE_BAUDRATE_Baud38400
	};

	APP_UART_FIFO_INIT(&comm_params,
										 UART_RX_BUF_SIZE,
										 UART_TX_BUF_SIZE,
										 uart_error_handle,
										 APP_IRQ_PRIORITY_LOW,
										 err_code);

	APP_ERROR_CHECK(err_code);
			
}

/** @} */
