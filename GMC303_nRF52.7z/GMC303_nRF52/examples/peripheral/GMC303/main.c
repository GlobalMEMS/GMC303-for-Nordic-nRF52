/* Copyright (c) 2014 Nordic Semiconductor. All Rights Reserved.
 *
 * The information contained herein is property of Nordic Semiconductor ASA.
 * Terms and conditions of usage are described in detail in NORDIC
 * SEMICONDUCTOR STANDARD SOFTWARE LICENSE AGREEMENT.
 *
 * Licensees are granted free, non-transferable use of the information. NO
 * WARRANTY of ANY KIND is provided. This heading must NOT be removed from
 * the file.
 *
 */

/** @file
 * @defgroup nrf_dev_timer_example_main main.c
 * @{
 * @ingroup nrf_dev_timer_example
 * @brief Timer Example Application main file.
 *
 * This file contains the source code for a sample application using Timer0.
 *
 */

#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "app_uart.h"
#include "nrf.h"
#include "bsp.h"
#include "nrf_drv_twi.h"
#include "nrf_drv_timer.h"
#include "bsp.h"
#include "app_error.h"
#include "app_uart.h"
#include "I2C.h"
#include "gmc303.h"
#include "nrf_delay.h"

#include "AKFS_Compass.h"
#include "AKFS_Device.h"
#include "AKFS_APIs.h"

raw_data_xyzt_t gRawData, mRawData;
float_xyzt_t mCalibData;
float_xyzt_t gOffsetData;
float_xyzt_t mAdjustVal = { 1.0, 1.0, 1.0, 0.0 };
float SOFT_IRON_MATRIX[3][3]={{1.0f,0.0f,0.0f},{0.0f,1.0f,0.0f},{0.0f,0.0f,1.0f}}; //Soft iron matrix
int16_t i16AkmdfsRes, i16Accuracy, i16Accuracy_pre, i16Orientation;
int16_t i16RawData[3];
//float_xyzt_t fv_avec;
float_xyzt_t fv_hvec;
AKMPRMS akmdfsPRMS;
AKFVEC fv_ho_pre = {0.0f, 0.0f, 0.0f};
AKFLOAT f_azimuth;
AKFLOAT f_pitch;
AKFLOAT f_roll;
uint8_t u8Asaxyz[3]; //ASAX/Y/Z
//const int32_t akfs_over_sampling_ratio = (int32_t)(SAMPLING_RATE_HZ / AKFS_DATA_RATE_HZ + 0.5);
int32_t akfsIcounter = 0;
#define MAG_LAYOUT_PATTERN PAT1


#define MAX_TEST_DATA_BYTES     (15U)                /**< max number of test bytes to be used for tx and rx. */
#define UART_TX_BUF_SIZE 256                         /**< UART TX buffer size. */
#define UART_RX_BUF_SIZE 1                           /**< UART RX buffer size. */
#define DELAY_MS(ms)	nrf_delay_us(ms*1000)

const nrf_drv_timer_t TIMER_LED = NRF_DRV_TIMER_INSTANCE(0);
const uint8_t leds_list[LEDS_NUMBER] = LEDS_LIST;

void timer_led_event_handler(nrf_timer_event_t event_type, void* p_context);
void timer_LED_init(void);
void uart_init(void);
void uart_error_handle(app_uart_evt_t * p_event);
static const nrf_drv_twi_t m_twi_master = NRF_DRV_TWI_INSTANCE(1);
static ret_code_t twi_master_init(void);

volatile bool timer_flag=0;





/**
 * @brief Function for main application entry.
 */
int main(void)
{
		int8_t res,i;
		timer_LED_init();
    uart_init();
    twi_master_init();
						
		res=gmc303_bus_init();
		printf("CMPID=0x%02x\n\r",res);
			
		/* GMC303 soft reset */
		gmc303_soft_reset();
		
		/* Wait 10ms for reset complete */
		DELAY_MS(10);  

		/* GMC303 get the sensitivity adjust values */
		gmc303_get_sensitivity_adjust_val(&mAdjustVal);	
		printf("mAdjustVal=%8.3f,%8.3f,%8.3f\n\r",mAdjustVal.u.x,mAdjustVal.u.y,mAdjustVal.u.z);
		gmc303_burst_read(GMC303_ASA_XYZ_START__REG, u8Asaxyz, 3);

	  //Set to CM 100Hz
		res=gmc303_set_operation_mode(GMC303_OP_MODE_CM_100HZ);  
		printf("GMC303_OP_MODE_CM_100HZ=%s\n\r",res>0?"SUCCESS":"FAIL");
	
		i16AkmdfsRes = AKFS_Init(&akmdfsPRMS, MAG_LAYOUT_PATTERN , u8Asaxyz, gOffsetData.v, GMC303_RAW_DATA_SENSITIVITY);
		printf("%s: AKFS_Init\n\r",(i16AkmdfsRes == AKM_SUCCESS)?"Success":"Fail");

		i16AkmdfsRes = AKFS_Start(&akmdfsPRMS);


		printf("%s: AKFS_Start\n\r",(i16AkmdfsRes == AKM_SUCCESS)?"Success":"Fail");
		printf("hstatus=%d\n\r",akmdfsPRMS.i16_hstatus);
    while(1)
    {
			while(timer_flag==0);
			gmc303_read_data_xyz(&mRawData);
			for(i = 0; i < 3; ++i)
			{
				i16RawData[i] = mRawData.v[i];
      }
      i16AkmdfsRes =AKFS_Get_MAGNETIC_FIELD(&akmdfsPRMS,i16RawData,0x01,  //success
				&fv_hvec.u.x, &fv_hvec.u.y, &fv_hvec.u.z,
				&i16Accuracy);	
			//printf("%s: AKFS_Get_MAGNETIC_FIELD\n\r",(i16AkmdfsRes == AKM_SUCCESS)?"Success":"Fail");
      printf("Raw=(%5d,%5d,%5d),",i16RawData[0],i16RawData[1],i16RawData[2]);	
      printf(" uT=(%6.1f,%6.1f,%6.1f), ",fv_hvec.u.x,fv_hvec.u.y,fv_hvec.u.z);	
			printf("i16Accuracy=%d,%5.1f ",i16Accuracy,sqrt(fv_hvec.u.x*fv_hvec.u.x+fv_hvec.u.y*fv_hvec.u.y+fv_hvec.u.z*fv_hvec.u.z)); 
      printf("offset=%6.1f,%6.1f,%6.1f\n\r",akmdfsPRMS.fv_ho.u.x,akmdfsPRMS.fv_ho.u.y,akmdfsPRMS.fv_ho.u.z);	

			timer_flag=0;				
      __WFI();	
    }
}


/**
 * @brief Initialize the master TWI
 *
 * Function used to initialize master TWI interface that would communicate with simulated EEPROM.
 *
 * @return NRF_SUCCESS or the reason of failure
 */
static ret_code_t twi_master_init(void)
{
	ret_code_t ret;
	uint32_t err_code = NRF_SUCCESS;
	const nrf_drv_twi_config_t config =
	{
		 .scl                = TWI1_CONFIG_SCL,
		 .sda                = TWI1_CONFIG_SDA,
		 .frequency          = NRF_TWI_FREQ_400K,
		 .interrupt_priority = APP_IRQ_PRIORITY_HIGH
	};

	do
	{
			ret = nrf_drv_twi_init(&m_twi_master, &config, NULL);
			if(NRF_SUCCESS != ret)
			{
					break;
			}
			nrf_drv_twi_enable(&m_twi_master);
	}while(0);
	APP_ERROR_CHECK(err_code);

	return ret;
}

void uart_error_handle(app_uart_evt_t * p_event)
{
    if (p_event->evt_type == APP_UART_COMMUNICATION_ERROR)
    {
        APP_ERROR_HANDLER(p_event->data.error_communication);
    }
    else if (p_event->evt_type == APP_UART_FIFO_ERROR)
    {
        APP_ERROR_HANDLER(p_event->data.error_code);
    }
}

/**
 * @brief Handler for timer events.
 */
void timer_led_event_handler(nrf_timer_event_t event_type, void* p_context)
{
    static uint32_t i;
    uint32_t led_to_invert = (1 << leds_list[(i++) % LEDS_NUMBER]);
    switch(event_type)
    {
        case NRF_TIMER_EVENT_COMPARE0:
            LEDS_INVERT(led_to_invert);
            break;
        
        default:
            //Do nothing.
            break;
    }    
		timer_flag=1;
}

void timer_LED_init(void)
{
	  uint32_t time_ms = 125; //Time(in miliseconds) between consecutive compare events.
    uint32_t time_ticks;
    uint32_t err_code = NRF_SUCCESS;
    
    //Configure all leds on board.
    LEDS_CONFIGURE(LEDS_MASK);
    LEDS_OFF(LEDS_MASK);
    
    //Configure TIMER_LED for generating simple light effect - leds on board will invert his state one after the other.
    err_code = nrf_drv_timer_init(&TIMER_LED, NULL, timer_led_event_handler);
    APP_ERROR_CHECK(err_code);
    
    time_ticks = nrf_drv_timer_ms_to_ticks(&TIMER_LED, time_ms);
    
    nrf_drv_timer_extended_compare(
         &TIMER_LED, NRF_TIMER_CC_CHANNEL0, time_ticks, NRF_TIMER_SHORT_COMPARE0_CLEAR_MASK, true);
    
    nrf_drv_timer_enable(&TIMER_LED);
}	

void uart_init(void)
{
	uint32_t err_code = NRF_SUCCESS;

	const app_uart_comm_params_t comm_params =
	{
			RX_PIN_NUMBER,
			TX_PIN_NUMBER,
			RTS_PIN_NUMBER,
			CTS_PIN_NUMBER,
			APP_UART_FLOW_CONTROL_ENABLED,
			false,
			UART_BAUDRATE_BAUDRATE_Baud38400
	};

	APP_UART_FIFO_INIT(&comm_params,
										 UART_RX_BUF_SIZE,
										 UART_TX_BUF_SIZE,
										 uart_error_handle,
										 APP_IRQ_PRIORITY_LOW,
										 err_code);

	APP_ERROR_CHECK(err_code);
			
}

/** @} */
