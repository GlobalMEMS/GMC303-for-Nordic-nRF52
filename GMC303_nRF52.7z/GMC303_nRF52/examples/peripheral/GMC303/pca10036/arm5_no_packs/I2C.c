#include "I2C.h"
#include "nrf_drv_twi.h"


bool i2c_write(uint8_t device_address, uint8_t register_address, uint8_t *value, uint8_t number_of_bytes )
{  
 #define i2c_write_data_len 6
 uint8_t w2_data[i2c_write_data_len+1], i;
 
 const nrf_drv_twi_t twi = NRF_DRV_TWI_INSTANCE(1);
 nrf_drv_twi_init(&twi, NULL, NULL);
    
 w2_data[0] = register_address;
 for ( i = 0 ; i < number_of_bytes ; i++ ) {
  w2_data[i +1] = value[i];  
 }
 
 nrf_drv_twi_enable(&twi);
 nrf_drv_twi_tx(&twi, (device_address), w2_data, number_of_bytes+1, false);
 
 return true;
}
 
bool i2c_read(uint8_t device_address, uint8_t register_address, uint8_t * destination, uint8_t number_of_bytes)
{  
 const nrf_drv_twi_t twi = NRF_DRV_TWI_INSTANCE(1);
 nrf_drv_twi_init(&twi, NULL, NULL);
 nrf_drv_twi_enable(&twi);
  
 nrf_drv_twi_tx(&twi, (device_address), &register_address, 1, true);
 nrf_drv_twi_rx(&twi, (device_address), destination, number_of_bytes,false);
   
 return true;  
}
