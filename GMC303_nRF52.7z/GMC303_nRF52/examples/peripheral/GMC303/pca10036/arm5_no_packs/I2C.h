#ifndef __I2C_H
#define __I2C_H

#include <stdbool.h>
#include <stdint.h>

bool i2c_write( uint8_t device_address, uint8_t register_address, uint8_t *value, uint8_t number_of_bytes );
bool i2c_read( uint8_t device_address, uint8_t register_address, uint8_t *destination, uint8_t number_of_bytes );


#endif
